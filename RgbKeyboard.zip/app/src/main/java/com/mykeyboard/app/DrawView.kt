package com.mykeyboard.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

class DrawView(context: Context) : View(context) {

    companion object {
        const val SIZE = 512
    }

    private val bmp: Bitmap = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
    private val cv = Canvas(bmp)
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 26f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val guide = Paint().apply {
        color = 0xFF3A3A46.toInt()
        strokeWidth = 2f
    }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private var lastX = 0f
    private var lastY = 0f

    var edited = false
        private set

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0xFF16161D.toInt())
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawLine(0f, h * 0.2f, w, h * 0.2f, guide)
        canvas.drawLine(0f, h * 0.5f, w, h * 0.5f, guide)
        canvas.drawLine(0f, h * 0.8f, w, h * 0.8f, guide)
        canvas.drawBitmap(bmp, null, RectF(0f, 0f, w, h), bmpPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (width == 0) return false
        val s = SIZE.toFloat() / width
        val x = e.x * s
        val y = e.y * s
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                path.reset()
                path.moveTo(x, y)
                path.lineTo(x + 0.01f, y)
                cv.drawPath(path, ink)
                lastX = x
                lastY = y
                edited = true
            }
            MotionEvent.ACTION_MOVE -> {
                path.quadTo(lastX, lastY, (x + lastX) / 2f, (y + lastY) / 2f)
                cv.drawPath(path, ink)
                lastX = x
                lastY = y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                path.lineTo(x, y)
                cv.drawPath(path, ink)
                path.reset()
            }
        }
        invalidate()
        return true
    }

    fun clear() {
        bmp.eraseColor(Color.TRANSPARENT)
        edited = false
        invalidate()
    }

    fun loadBitmap(b: Bitmap?) {
        bmp.eraseColor(Color.TRANSPARENT)
        if (b != null) cv.drawBitmap(b, null, Rect(0, 0, SIZE, SIZE), null)
        edited = false
        invalidate()
    }

    fun snapshot(): Bitmap = bmp.copy(Bitmap.Config.ARGB_8888, false)
}
