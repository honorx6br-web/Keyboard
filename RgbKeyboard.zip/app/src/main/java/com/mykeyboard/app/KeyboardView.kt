package com.mykeyboard.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View

enum class Act { CHAR, SHIFT, DEL, SPACE, LANG, ENTER }

class Key(
    val lo: String,
    val hi: String = lo,
    val w: Float = 1f,
    val act: Act = Act.CHAR
) {
    val rect = RectF()
    var isDown = false
    var releasedAt = 0L
    var hue = 0f
}

class KeyboardView(ctx: Context, private val svc: KeyboardService) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val sp = resources.displayMetrics.scaledDensity
    private val keyH = 46 * d
    private val gap = 5 * d
    private val padH = 4 * d
    private val padTop = 12 * d
    private val depth = 4 * d
    private val corner = 8 * d

    private var bangla = false
    private var shift = false
    private var hueCounter = 0f
    private var rows: List<List<Key>> = buildRows()

    private val handler = Handler(Looper.getMainLooper())
    private val glyphs = HashMap<Char, Bitmap?>()
    private val pointerKeys = HashMap<Int, Key>()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val tmp = RectF()

    private val repeat = object : Runnable {
        override fun run() {
            svc.deleteBack()
            handler.postDelayed(this, 55)
        }
    }

    private fun letters(s: String): List<Key> =
        s.map { Key(it.toString(), it.uppercaseChar().toString()) }

    private fun pairs(l: List<String>): List<Key> =
        l.map {
            val s = it.split("|")
            Key(s[0], s[1])
        }

    private fun buildRows(): List<List<Key>> {
        val shiftKey = Key("▲", w = 1.5f, act = Act.SHIFT)
        val delKey = Key("←", w = 1.5f, act = Act.DEL)
        val bottom = listOf(
            Key(if (bangla) "EN" else "বাং", w = 1.5f, act = Act.LANG),
            Key(","),
            Key(" ", w = 4f, act = Act.SPACE),
            Key("."),
            Key("↵", w = 1.5f, act = Act.ENTER)
        )
        return if (bangla) {
            listOf(
                "১২৩৪৫৬৭৮৯০".map { Key(it.toString()) },
                pairs(
                    listOf(
                        "ঙ|\u0982", "য|\u09DF", "ড|ঢ", "প|ফ", "ট|ঠ",
                        "চ|ছ", "জ|ঝ", "হ|ঞ", "গ|ঘ", "\u09DC|\u09DD"
                    )
                ),
                pairs(
                    listOf(
                        "\u09C3|\u09B0\u09CD", "\u09C1|\u09C2", "\u09BF|\u09C0",
                        "\u09BE|অ", "\u09CD|\u0964", "ব|ভ", "ক|খ", "ত|থ", "দ|ধ"
                    )
                ),
                listOf(shiftKey) + pairs(
                    listOf(
                        "\u09CD\u09B0|\u09CD\u09AF", "ও|ঔ", "\u09C7|\u09C8",
                        "র|ল", "ন|ণ", "স|ষ", "ম|শ"
                    )
                ) + listOf(delKey),
                bottom
            )
        } else {
            listOf(
                "1234567890".map { Key(it.toString()) },
                letters("qwertyuiop"),
                letters("asdfghjkl"),
                listOf(shiftKey) + letters("zxcvbnm") + listOf(delKey),
                bottom
            )
        }
    }

    fun reloadGlyphs() {
        glyphs.clear()
        invalidate()
    }

    private fun glyph(ch: Char): Bitmap? {
        if (!GlyphStore.CHARS.contains(ch)) return null
        if (!glyphs.containsKey(ch)) glyphs[ch] = GlyphStore.loadSmall(context, ch)
        return glyphs[ch]
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (padTop + rows.size * (keyH + gap) + 6 * d).toInt()
        setMeasuredDimension(w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys()
    }

    private fun layoutKeys() {
        val w = width.toFloat()
        if (w <= 0f) return
        var y = padTop
        for (row in rows) {
            var total = 0f
            for (k in row) total += k.w
            val avail = w - 2 * padH - gap * (row.size - 1)
            val unit = avail / total
            var x = padH
            for (k in row) {
                val kw = unit * k.w
                k.rect.set(x, y, x + kw, y + keyH)
                x += kw + gap
            }
            y += keyH + gap
        }
    }

    private fun hsv(h: Float): Int = Color.HSVToColor(floatArrayOf(h, 0.85f, 1f))

    private fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun gOf(k: Key, now: Long): Float {
        var g = if (k.isDown) 1f else (1f - (now - k.releasedAt) / 500f).coerceIn(0f, 1f)
        if (k.act == Act.SHIFT && shift) g = maxOf(g, 0.9f)
        return g
    }

    private fun hueOf(k: Key): Float = if (k.act == Act.SHIFT && shift) 190f else k.hue

    private fun display(s: String): String {
        if (s.isEmpty()) return s
        val c = s[0]
        val sign = c in '\u09BE'..'\u09CD' || c == '\u0982' || c == '\u0981' || c == '\u0983'
        return if (sign) "\u25CC" + s else s
    }

    private fun labelOf(k: Key): String = when (k.act) {
        Act.CHAR -> display(if (shift) k.hi else k.lo)
        else -> k.lo
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        canvas.drawColor(0xFF0F0F14.toInt())
        drawBar(canvas, 0f, now)
        drawBar(canvas, height - 3 * d, now)
        for (row in rows) for (k in row) drawGlow(canvas, k, now)
        for (row in rows) for (k in row) drawFace(canvas, k, now)
        postInvalidateDelayed(50)
    }

    private fun drawBar(c: Canvas, y: Float, now: Long) {
        val n = 32
        val sw = width.toFloat() / n
        p.style = Paint.Style.FILL
        for (i in 0 until n) {
            p.color = hsv(((now / 12f) + i * 360f / n) % 360f)
            c.drawRect(i * sw, y, (i + 1) * sw + 1f, y + 3 * d, p)
        }
    }

    private fun drawGlow(c: Canvas, k: Key, now: Long) {
        val g = gOf(k, now)
        if (g <= 0f) return
        val glow = hsv(hueOf(k))
        val r = k.rect
        val off = if (k.isDown) depth * 0.75f else 0f
        p.style = Paint.Style.FILL
        for (i in 3 downTo 1) {
            val a = (70 * g / i).toInt()
            p.color = Color.argb(a, Color.red(glow), Color.green(glow), Color.blue(glow))
            val e = i * 2.5f * d
            tmp.set(r.left - e, r.top + off - e, r.right + e, r.bottom + off + e)
            c.drawRoundRect(tmp, corner + e, corner + e, p)
        }
    }

    private fun drawFace(c: Canvas, k: Key, now: Long) {
        val g = gOf(k, now)
        val glow = hsv(hueOf(k))
        val r = k.rect
        val off = if (k.isDown) depth * 0.75f else 0f

        p.style = Paint.Style.FILL
        p.color = 0xFF101015.toInt()
        tmp.set(r.left, r.top + depth, r.right, r.bottom + depth)
        c.drawRoundRect(tmp, corner, corner, p)

        val ft = r.top + off
        val fb = r.bottom + off
        tmp.set(r.left, ft, r.right, fb)
        p.color = blend(0xFF2A2A33.toInt(), glow, g * 0.2f)
        c.drawRoundRect(tmp, corner, corner, p)

        p.style = Paint.Style.STROKE
        p.strokeWidth = d
        p.color = blend(0xFF3A3A46.toInt(), glow, g)
        c.drawRoundRect(tmp, corner, corner, p)

        p.color = 0x24FFFFFF
        c.drawLine(r.left + corner, ft + d, r.right - corner, ft + d, p)
        p.style = Paint.Style.FILL

        val label = labelOf(k)
        val col = blend(0xFFE8E8EE.toInt(), glow, g)
        val cx = (r.left + r.right) / 2f
        val cy = (ft + fb) / 2f
        val bmp = if (!bangla && k.act == Act.CHAR && label.length == 1) glyph(label[0]) else null
        if (bmp != null) {
            val s = keyH * 0.82f
            tmp.set(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2)
            bp.colorFilter = PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN)
            c.drawBitmap(bmp, null, tmp, bp)
        } else if (k.act == Act.SPACE) {
            tp.textSize = 12 * sp
            tp.color = 0xFF7A7A88.toInt()
            drawCentered(c, if (bangla) "বাংলা" else "English", cx, cy)
        } else {
            tp.textSize = 20 * sp
            tp.color = col
            drawCentered(c, label, cx, cy)
        }
    }

    private fun drawCentered(c: Canvas, s: String, cx: Float, cy: Float) {
        val fm = tp.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, tp)
    }

    private fun keyAt(x: Float, y: Float): Key? {
        val e = gap / 2f
        for (row in rows) for (k in row) {
            val r = k.rect
            if (x >= r.left - e && x <= r.right + e && y >= r.top - e && y <= r.bottom + e) return k
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                press(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                release(e.getPointerId(e.actionIndex))
            }
            MotionEvent.ACTION_CANCEL -> {
                for (id in pointerKeys.keys.toList()) release(id)
            }
        }
        return true
    }

    private fun press(id: Int, x: Float, y: Float) {
        val k = keyAt(x, y) ?: return
        pointerKeys[id] = k
        k.isDown = true
        hueCounter = (hueCounter + 47f) % 360f
        k.hue = hueCounter
        when (k.act) {
            Act.CHAR -> {
                svc.typeText(if (shift) k.hi else k.lo, bangla)
                shift = false
            }
            Act.SHIFT -> shift = !shift
            Act.DEL -> {
                svc.deleteBack()
                handler.postDelayed(repeat, 400)
            }
            Act.SPACE -> svc.space()
            Act.LANG -> {
                bangla = !bangla
                shift = false
                svc.resetState()
                rows = buildRows()
                layoutKeys()
            }
            Act.ENTER -> svc.enter()
        }
        invalidate()
    }

    private fun release(id: Int) {
        val k = pointerKeys.remove(id) ?: return
        k.isDown = false
        k.releasedAt = SystemClock.uptimeMillis()
        if (k.act == Act.DEL) handler.removeCallbacks(repeat)
        invalidate()
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(repeat)
        super.onDetachedFromWindow()
    }
}
