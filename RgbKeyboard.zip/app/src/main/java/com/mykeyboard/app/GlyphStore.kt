package com.mykeyboard.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

object GlyphStore {
    const val CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

    private fun dir(ctx: Context): File = File(ctx.filesDir, "glyphs").apply { mkdirs() }

    private fun file(ctx: Context, c: Char): File = File(dir(ctx), "u${c.code}.png")

    fun save(ctx: Context, c: Char, bmp: Bitmap) {
        FileOutputStream(file(ctx, c)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun load(ctx: Context, c: Char): Bitmap? {
        val f = file(ctx, c)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    fun has(ctx: Context, c: Char): Boolean = file(ctx, c).exists()

    fun count(ctx: Context): Int = CHARS.count { has(ctx, it) }
}
