package com.mykeyboard.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private var idx = 0
    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var draw: DrawView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        title = TextView(this).apply {
            textSize = 24f
            setTextColor(Color.WHITE)
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF9A9AA8.toInt())
            setPadding(0, 0, 0, pad / 2)
        }
        draw = DrawView(this)

        col.addView(title)
        col.addView(status)
        col.addView(
            draw,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, pad / 2, 0, 0)
        }
        row1.addView(button("◀ আগের") { move(-1) }, weight())
        row1.addView(button("পরের ▶") { move(1) }, weight())

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        row2.addView(button("মুছুন") { draw.clear() }, weight())
        row2.addView(button("সেভ করুন") { saveCurrent() }, weight())

        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, pad / 2, 0, 0)
        }
        row3.addView(button("কীবোর্ড চালু করুন") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, weight())
        row3.addView(button("কীবোর্ড বদলান") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, weight())

        val test = EditText(this).apply {
            hint = "এখানে টাইপ করে দেখুন"
            textSize = 18f
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF7A7A88.toInt())
        }

        col.addView(row1)
        col.addView(row2)
        col.addView(row3)
        col.addView(test)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF0F0F14.toInt())
            addView(col)
        })
        show()
    }

    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun button(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun move(step: Int) {
        val n = GlyphStore.CHARS.length
        idx = (idx + step + n) % n
        show()
    }

    private fun saveCurrent() {
        if (!draw.edited) {
            Toast.makeText(this, "আগে অক্ষরটা আঁকুন", Toast.LENGTH_SHORT).show()
            return
        }
        GlyphStore.save(this, GlyphStore.CHARS[idx], draw.snapshot())
        Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
        move(1)
    }

    private fun show() {
        val c = GlyphStore.CHARS[idx]
        title.text = "আঁকুন: $c"
        draw.loadBitmap(GlyphStore.load(this, c))
        val saved = if (GlyphStore.has(this, c)) "সেভ আছে" else "সেভ নেই"
        status.text = "$saved · মোট ${GlyphStore.count(this)}/${GlyphStore.CHARS.length}"
    }
}
