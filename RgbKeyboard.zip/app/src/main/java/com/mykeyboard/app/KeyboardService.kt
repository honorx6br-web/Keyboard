package com.mykeyboard.app

import android.content.ClipDescription
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputContentInfo
import android.widget.Toast
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo

class KeyboardService : InputMethodService() {

    private var view: KeyboardView? = null

    // Bijoy-style typing: vowel signs ি ে ৈ are typed before the consonant
    private var justPre: String? = null
    private var moved: String? = null
    private var waiting = false

    override fun onCreateInputView(): View {
        val v = KeyboardView(this, this)
        view = v
        return v
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetState()
        view?.reloadGlyphs()
    }

    fun resetState() {
        justPre = null
        moved = null
        waiting = false
    }

    private fun isPre(s: String): Boolean =
        s == "\u09BF" || s == "\u09C7" || s == "\u09C8"

    private fun isCons(s: String): Boolean {
        if (s.isEmpty()) return false
        val c = s[0]
        return c in '\u0995'..'\u09B9' || c in '\u09DC'..'\u09DF' || c == '\u09CE'
    }

    fun typeText(s: String, bangla: Boolean) {
        val ic = currentInputConnection ?: return
        if (!bangla) {
            resetState()
            ic.commitText(s, 1)
            return
        }
        val jp = justPre
        if (jp != null) {
            justPre = null
            if (isCons(s)) {
                ic.deleteSurroundingText(jp.length, 0)
                ic.commitText(s + jp, 1)
                moved = jp
                return
            }
        }
        val mv = moved
        if (mv != null) {
            if (waiting) {
                if (isCons(s)) {
                    ic.commitText(s + mv, 1)
                    waiting = false
                    return
                }
                ic.commitText(mv, 1)
                waiting = false
                moved = null
            } else if (s == "\u09CD") {
                ic.deleteSurroundingText(mv.length, 0)
                ic.commitText(s, 1)
                waiting = true
                return
            } else if (s.startsWith("\u09CD")) {
                ic.deleteSurroundingText(mv.length, 0)
                ic.commitText(s + mv, 1)
                return
            } else if (s == "\u09BE" && mv == "\u09C7") {
                ic.deleteSurroundingText(1, 0)
                ic.commitText("\u09CB", 1)
                moved = null
                return
            } else {
                moved = null
            }
        }
        if (isPre(s)) {
            ic.commitText(s, 1)
            justPre = s
            return
        }
        ic.commitText(s, 1)
    }

    fun deleteBack() {
        resetState()
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    fun space() {
        resetState()
        currentInputConnection?.commitText(" ", 1)
    }

    private fun supportsImage(info: EditorInfo?): Boolean {
        val ex = info?.extras ?: return false
        val keys = arrayOf(
            "androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES",
            "android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES"
        )
        for (k in keys) {
            val arr = ex.getStringArray(k) ?: continue
            for (m in arr) if (m.startsWith("image/")) return true
        }
        return false
    }

    fun sendImage() {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(500, 0)?.toString() ?: ""
        val after = ic.getTextAfterCursor(500, 0)?.toString() ?: ""
        val text = (before + after).trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "আগে কিছু লিখুন", Toast.LENGTH_SHORT).show()
            return
        }
        val file = ImageRenderer.renderToFile(this, text)
        if (file == null) {
            Toast.makeText(this, "ছবি বানানো যায়নি", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = Uri.Builder()
            .scheme("content")
            .authority(ImageProvider.AUTHORITY)
            .appendPath(file.name)
            .build()

        var ok = false
        if (supportsImage(currentInputEditorInfo)) {
            val desc = ClipDescription("image", arrayOf("image/png"))
            ok = ic.commitContent(
                InputContentInfo(uri, desc),
                InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION,
                null
            )
        }
        if (ok) {
            ic.deleteSurroundingText(before.length, after.length)
            resetState()
        } else {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(send, "ছবি পাঠান").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(chooser)
            } catch (e: Exception) {
                Toast.makeText(this, "ছবি পাঠানো যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun enter() {
        resetState()
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnter = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnter && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }
}
