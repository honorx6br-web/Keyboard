package com.mykeyboard.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import java.io.File
import java.io.FileOutputStream

private class Glyph(val bmp: Bitmap, val x0: Int, val x1: Int)

private class Item(val text: String, val glyph: Glyph?, val w: Float)

object ImageRenderer {

    private const val S = 110f
    private const val PAD = 48f
    private const val MAXW = 1080f

    private fun loadGlyph(ctx: Context, ch: Char): Glyph? {
        if (!GlyphStore.CHARS.contains(ch)) return null
        val b = GlyphStore.load(ctx, ch) ?: return null
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        var x0 = w
        var x1 = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if ((px[y * w + x] ushr 24) > 20) {
                    if (x < x0) x0 = x
                    if (x > x1) x1 = x
                }
            }
        }
        if (x1 < 0) return null
        return Glyph(b, maxOf(0, x0 - 6), minOf(w - 1, x1 + 6))
    }

    fun renderToFile(ctx: Context, text: String): File? {
        return try {
            val cache = HashMap<Char, Glyph?>()
            fun glyph(ch: Char): Glyph? {
                if (!cache.containsKey(ch)) cache[ch] = loadGlyph(ctx, ch)
                return cache[ch]
            }

            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = S * 0.8f }
            val gap = S * 0.08f
            val spaceW = S * 0.35f
            val limit = MAXW - 2 * PAD

            val lines = ArrayList<ArrayList<Item>>()
            var cur = ArrayList<Item>()
            var curW = 0f

            fun newLine() {
                lines.add(cur)
                cur = ArrayList()
                curW = 0f
            }

            fun addItem(item: Item) {
                if (curW + item.w > limit && cur.isNotEmpty()) newLine()
                cur.add(item)
                curW += item.w
            }

            val run = StringBuilder()
            fun flush() {
                if (run.isNotEmpty()) {
                    val s = run.toString()
                    addItem(Item(s, null, tp.measureText(s) + gap))
                    run.setLength(0)
                }
            }

            for (ch in text) {
                if (ch == '\n') {
                    flush()
                    newLine()
                } else if (ch == ' ') {
                    flush()
                    addItem(Item(" ", null, spaceW))
                } else {
                    val g = glyph(ch)
                    if (g != null) {
                        flush()
                        addItem(Item(ch.toString(), g, (g.x1 - g.x0) * S / g.bmp.width + gap))
                    } else {
                        run.append(ch)
                    }
                }
            }
            flush()
            lines.add(cur)

            var maxW = 0f
            for (l in lines) {
                var w = 0f
                for (i in l) w += i.w
                if (w > maxW) maxW = w
            }
            val lineH = S * 1.25f
            val width = (maxW + 2 * PAD).toInt().coerceAtLeast((S + 2 * PAD).toInt())
            val height = (lines.size * lineH + 2 * PAD).toInt()

            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.drawColor(0xFF0F0F14.toInt())
            val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

            var n = 0
            var y = PAD
            for (l in lines) {
                var x = PAD
                for (item in l) {
                    val col = Color.HSVToColor(floatArrayOf((n * 25f) % 360f, 0.85f, 1f))
                    val g = item.glyph
                    if (g != null) {
                        val gw = (g.x1 - g.x0) * S / g.bmp.width
                        bp.colorFilter = PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN)
                        c.drawBitmap(
                            g.bmp,
                            Rect(g.x0, 0, g.x1 + 1, g.bmp.height),
                            RectF(x, y, x + gw, y + S),
                            bp
                        )
                        n++
                    } else if (item.text != " ") {
                        tp.color = col
                        c.drawText(item.text, x, y + S * 0.8f, tp)
                        n++
                    }
                    x += item.w
                }
                y += lineH
            }

            val dir = File(ctx.cacheDir, "out").apply { mkdirs() }
            val cutoff = System.currentTimeMillis() - 3600000L
            dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
            val f = File(dir, "msg_${System.currentTimeMillis()}.png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            f
        } catch (e: Exception) {
            null
        }
    }
}
